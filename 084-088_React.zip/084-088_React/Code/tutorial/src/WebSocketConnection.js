import CONSTANTS from "./constants";

export class WebSocketConnection {
  constructor(messageCallback) {
    // Attach an ID if the user has one from before
    // Connect to server
    // Attach listener for WebSocket events
    // Store reference to external callback for later
  }

  // What to do when we receive a message from the server
  onMessage(event) {
    // Convert the JSON string into an object
    // Set the new ID from the state passed
    // Pass to React if any other message
  }

  // Send a message to the server
  send(action, payload) {
    this.connection.send(
      JSON.stringify({
        action,
        payload
      })
    );
  }
}

// Get the ID from session storage
function getId() {
  return sessionStorage.getItem("id");
}

// Store the ID in session storage
function setId(id) {
  sessionStorage.setItem("id", id);
}

export default WebSocketConnection;
