window.addEventListener("load", function(){
	var nodes = document.querySelectorAll(".slide");
	for(var i=0; i<nodes.length; i++){
		var letters = nodes[i].innerText.split('').join('</span><span>');
		letters = letters.split(' ').join('&nbsp;');
		nodes[i].innerHTML = "<span>"+letters+"</span>";

		var children = nodes[i].childNodes;
		var x = 0;
		for(var n=0; n<children.length; n++){
			children[n].style.left = x+"px";
			children[n].style.zIndex = letters.length-n;
			x += children[n].offsetWidth;
		}

	}

});
